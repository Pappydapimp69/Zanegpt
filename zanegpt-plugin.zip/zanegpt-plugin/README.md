# ZaneGPT Plugin

This is a skill-only plugin package intended to reproduce the public-facing ZaneGPT interaction style in ChatGPT/Codex plugin-capable environments.

## Contents
- `.claude-plugin/plugin.json` — standalone plugin manifest in a format supported by OpenAI workspace plugin import.
- `skills/zanegpt/SKILL.md` — reusable ZaneGPT behavior skill.

## Import through GitHub
1. Create a GitHub repository and copy this folder's contents into the repository root.
2. In an eligible ChatGPT workspace, go to Workspace settings → Plugins → Add → Import marketplace.
3. Enter the repository URL.
4. Import and review the plugin's installation policy.
5. In Codex, open Sources → Use plugins and select ZaneGPT once available.

OpenAI notes that plugin/skill availability depends on plan, workspace, role, region, and product surface.

## Optional next step
Add a GitHub-backed app/MCP capability if you want ZaneGPT to read or act on repositories, rather than only contribute reusable behavior.
